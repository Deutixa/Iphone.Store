﻿namespace Store.ViewModels
{
    public class EntityBaseViewModel
    {
        public int Id { get; set; }
    }
}
