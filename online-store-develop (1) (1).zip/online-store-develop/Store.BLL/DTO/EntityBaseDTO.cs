﻿namespace Store.BLL.DTO;

public class EntityBaseDTO
{
    public int Id { get; set; }
}