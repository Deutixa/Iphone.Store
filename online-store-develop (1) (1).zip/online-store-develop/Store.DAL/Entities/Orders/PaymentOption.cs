﻿using Store.DAL.Entities.Base;

namespace Store.DAL.Entities.Orders
{
    public class PaymentOption : EntityBase
    {
        public string Name { get; set; }
    }
}
