﻿using Store.DAL.Entities.Base;

namespace Store.DAL.Entities.Orders
{
    public class DeliveryOption : EntityBase
    {
        public string Name { get; set; }
    }
}
