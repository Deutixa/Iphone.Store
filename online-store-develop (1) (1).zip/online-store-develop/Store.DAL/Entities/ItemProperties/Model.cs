﻿using Store.DAL.Entities.Base;

namespace Store.DAL.Entities.ItemProperties
{
    public class Model : EntityBase
    {
        public string Name { get; set; }
    }
}
